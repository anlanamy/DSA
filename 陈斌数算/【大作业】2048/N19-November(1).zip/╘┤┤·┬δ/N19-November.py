# 基于随机算法的模版AI
# 此处采取的算法为优先在己方领域下, 己方满则在对方领域随机下

# 参赛队伍的AI要求:
#
# 须写在Player类里
#
# 须实现两个方法:
#
# __init__(self, isFirst, array):
#   -> 初始化
#   -> 参数: isFirst是否先手, 为bool变量, isFirst = True 表示先手
#   -> 参数: array随机序列, 为一个长度等于总回合数的list
#
# output(self, currentRound, board, mode):
#   -> 给出己方的决策(下棋的位置或合并的方向)
#   -> 参数: currentRound当前轮数, 为从0开始的int
#   -> 参数: board棋盘对象
#   -> 参数: mode模式, mode = 'position' 对应位置模式, mode = 'direction' 对应方向模式, 如果为 '_position' 和 '_direction' 表示在对应模式下己方无法给出合法输出
#   -> 返回: 位置模式返回tuple (row, column), row行, 从上到下为0到3的int; column列, 从左到右为0到7的int
#   -> 返回: 方向模式返回direction = 0, 1, 2, 3 对应 上, 下, 左, 右
#   -> 返回: 在己方无法给出合法输出时, 对返回值不作要求
#
# 其余的属性与方法请自行设计


class Player:
    def __init__(self, isFirst, array):
        # 初始化
        self.isFirst = isFirst
        self.array = array

    def output(self, currentRound, board, mode):
        if mode == 'position':  # 如果要求给出落子
            another = board.getNext(self.isFirst, currentRound)  # 己方的允许落子点
            nextPos = None
            bestVal = -99999
            available = board.getNone(not self.isFirst)
            # 通过观察大部分棋局，发现绝大部分情况下在己方下棋收益更大，故己方有位置则直接在己方下
            if another != ():
                return another
            elif available:  # 在对方区域下棋时需要进行更进一步的决策
                for choice in available:  # 依次考察在对方每个可落子点时的收益
                    newBoard = board.copy()  # 备份棋盘
                    newBoard.add(self.isFirst, choice)  # 下在该点
                    if self.isFirst == True:  # 先手情况下
                        tempVal = self._min(newBoard, not self.isFirst, mode, 4, currentRound, -99999, 99999)
                    else:  # 后手情况下
                        tempVal = self._min(newBoard, not self.isFirst, 'direction', 4, currentRound, -99999, 99999)
                    if tempVal > bestVal:  # 选出收益最大的，作为最终的落子点
                        bestVal = tempVal
                        nextPos = choice
                return nextPos  # 返回要求位置
            else:  # 如果局面上无位置可下，返回空
                return

        elif mode == 'direction':  # 要求给出己方合并的方向
            directionList = [0, 1, 2, 3]
            nextDir = None
            bestVal = -99999
            tempVal = -99999
            hasmove = False  # 判断是否进行了有效的合并
            for direction in directionList:  # 依次考察每个合并方向的优劣
                newBoard = board.copy()  # 备份棋盘
                if newBoard.move(self.isFirst, direction) == True:  # 完成合并，顺便看看是否有效
                    hasmove = True  # 只要有一次是有效的，该判断值就更新为True
                    if self.isFirst == True:  # 先手情况
                        tempVal = self._min(newBoard, not self.isFirst, mode, 3, currentRound, -99999, 99999)
                    else:  # 后手情况
                        tempVal = self._min(newBoard, not self.isFirst, 'position', 3, currentRound + 1, -99999, 99999)
                    if tempVal > bestVal:  # bestval取最大值
                        bestVal = tempVal
                        nextDir = direction
            if hasmove:  # 如果某个方向合并有效，就返回该方向
                return nextDir
            else:  # 否则返回空值
                return
        else:
            return

    # 影响value函数的有5个因素，局面分数、单调性、平滑性、空格数、最大值
    def value(self, board):
        totalValweight = 1.0  # 权重 可更改
        monoweight = 0.3  # 单调性1 权重
        mono2weight = 0.4  # 单调性2 权重
        smoothweight = 0.2  # 光滑性 权重
        emptyweight = 0.8  # 空格数 权重
        maxweight = 1.0  # 最大值 权重

        res = monoweight * self.monotonicity(board) + mono2weight * self.monotonicity2(board) \
              + smoothweight * self.smoothness(board) + emptyweight * self.emptyCell(board) + \
              maxweight * self.maxValue(board) + totalValweight * self.totalValue(board)
        return res  # 计算并返回结果

    def totalValue(self, board):  # 局面分数，值越大对自己越有利，即自己分数减去对方分数的值
        score = 0
        for i in board.getScore(self.isFirst):
            score += i ** 2
        for i in board.getScore(not self.isFirst):
            score -= i ** 2
        return score

    def myMaxPosition(self, board):  # 获取己方区域最大点位置
        myMax = 0
        mypos = [0, 0]
        for i in range(4):
            for j in range(8):
                if board.getBelong((i, j)) == self.isFirst:  # 判断是否为自己的棋子
                    if (i, j) not in board.getNone(self.isFirst):  # 若不是空位
                        t = board.getValue((i, j))  # 返回该棋子的价值
                        if myMax < t:  # 若目前最大值小于当前值，把该值记录为新的最大值
                            myMax = t
                            mypos = [i, j]
        return mypos[0], mypos[1]  # 返回棋子的横纵坐标

    def smoothness(self, board):  # 光滑性，即棋子按照价值排列是否连续，值越大越好
        value = 0
        for x in range(4):  # 遍历整个棋局，进行四行
            myposition = []
            rowvalue = 0
            for i in range(8):  # 记录属于我方的棋局位置
                if board.getBelong((x, i)) == self.isFirst:
                    myposition.append(i)
            for i in range(len(myposition) - 1):  # 对属于我方的每个棋子
                difvalue = abs(board.getValue((x, i + 1)) - board.getValue((x, i)))
                rowvalue += difvalue  # 计算相邻两个棋子之间的绝对值
            value += rowvalue
        for y in range(8):  # 遍历整个棋局，进行八列，其余类似
            myposition = []
            linevalue = 0
            for i in range(4):
                if board.getBelong((i, y)) == self.isFirst:
                    myposition.append(i)
            if len(myposition) > 1:
                for i in range(len(myposition) - 1):
                    difvalue = abs(board.getValue((i + 1, y)) - board.getValue((i, y)))
                    linevalue += difvalue
                value += linevalue
        return -value

    def monotonicity(self, board):  # 单调性，值越大单调性越好
        xmax, ymax = self.myMaxPosition(board)  # 己方最大棋子的位置
        dirlst = [[-1, 0], [1, 0], [0, -1], [0, 1]]
        increases = 0
        tx = xmax
        ty = ymax
        for dir in dirlst:  # 向上下左右四个方向出发
            for i in range(1, 5):
                if i == 1:  # 从最大值开始向四周考察
                    tx = xmax
                    ty = xmax
                x = xmax + i * dir[0]
                y = ymax + i * dir[1]  # 离最高值越来越远
                if x in range(4) and y in range(8):  # 是否在棋盘中
                    if board.getBelong((x, y)) == self.isFirst:  # 是否在己方
                        targetvalue = board.getValue((x, y))  # 获取该点棋子的价值
                        value = board.getValue((tx, ty))  # 经过的己方前一棋子的价值
                        if targetvalue > value:  # 如果遇到考察的棋子价值高于经过的己方前一棋子的价值
                            increases += targetvalue - value  # 得到两者价值之差
                        tx = x
                        ty = y
        return -increases

    def monotonicity2(self, board):  # 单调性2，值越大越好
        totals = [0, 0, 0, 0]  # 四个维度，分别表示为横向递减，横向递增，纵向递减，纵向递增
        for x in range(4):  # 横向来看
            current = 0
            next2 = current + 1
            myposition = []
            for i in range(8):  # 找到自己的棋子位置，一一记录
                if board.getBelong((x, i)) == self.isFirst:
                    myposition.append(i)  # 添加到自己的棋子列表中
            lengthx = len(myposition)  # 记录总棋子数
            for i in range(lengthx - 1):  # 对自己的棋子列表而言，横向比较
                current = myposition[i]
                next2 = myposition[i + 1]
                currentValue = board.getValue((x, current))
                nextValue = board.getValue((x, next2))  # 得到自己的横向的相邻两个棋子的价值
                if currentValue > nextValue:  # 横向递减，标记为0
                    totals[0] += nextValue - currentValue  # 记录横向递减的值
                elif nextValue > currentValue:  # 横向递增，标记为1
                    totals[1] += currentValue - nextValue  # 记录横向递增的值

        for y in range(8):  # 纵向来看
            current = 0
            next2 = current + 1
            myposition = []
            for i in range(4):  # 找到自己的棋子位置，一一记录
                if board.getBelong((i, y)) == self.isFirst:
                    myposition.append(i)
            lengthy = len(myposition)  # 记录纵向的棋子数
            for i in range(lengthy - 1):  # 对自己的棋子，纵向比较
                current = myposition[i]
                next2 = myposition[i + 1]
                currentValue = board.getValue((current, y))
                nextValue = board.getValue((next2, y))  # 得到自己的纵向的相邻两个棋子的价值
                if currentValue > nextValue:  # 纵向递减，标记为2
                    totals[2] += nextValue - currentValue  # 记录纵向递减的值
                elif nextValue > currentValue:  # 纵向递增，标记为3
                    totals[3] += currentValue - nextValue  # 记录纵向递增的值
        return max(totals[0], totals[1]) + max(totals[2], totals[3])

    def maxValue(self, board):  # 获得当前值最大的棋子的价值
        if board.getScore(self.isFirst):
            val = board.getScore(self.isFirst)
            valmax = val.pop()
            return valmax
        return 0

    def emptyCell(self, board):  # 自己区域的空格数
        return len(board.getNone(self.isFirst))

    def _min(self, board, player, mode, n, currentRound, a=-99999, b=99999):  # 当前玩家为对手
        if n == 0:
            return self.value(board)
        else:
            if mode == 'position':  # 要求下棋
                newBoard = board.copy()  # 备份棋盘
                another = board.getNext(player, currentRound)  # 可以在自己区域落子的范围
                available = board.getNone(not player)  # 可以在对方区域落子的范围
                # 通过观察大部分棋局，发现绝大部分情况下在己方下棋收益更大，故己方有位置则直接在己方下
                if another != ():
                    newBoard.add(player, another)
                    if player == True:  # 先手情况下
                        return self._max(newBoard, not player, mode, n - 1, currentRound, a, b)
                    else:  # 后手情况下
                        return self._max(newBoard, not player, 'direction', n - 1, currentRound, a, b)
                elif available:  # 在对方区域下棋时需要进行更进一步的决策
                    for choice in available:  # 依次考察在对方每个可落子点时的收益
                        newBoard = board.copy()  # 备份棋盘
                        newBoard.add(player, choice)  # 下在该点
                        if player == True:  # 先手情况下
                            tempVal = self._max(newBoard, not player, mode, n - 1, currentRound, a, b)
                        else:  # 后手情况下
                            tempVal = self._max(newBoard, not player, 'direction', n - 1, currentRound, a, b)
                        if tempVal < b:  # 选出局面价值最小的
                            b = tempVal
                        if b <= a:  # 如果b<=a,直接返回a，完成枝剪
                            return a
                    return b
                else:  # 如果在棋盘上无可落子之地
                    if player == True:  # 先手情况下
                        return self._max(board, not player, mode, n - 1, currentRound, a, b)
                    else:  # 后手情况下
                        return self._max(board, not player, 'direction', n - 1, currentRound, a, b)

            else:  # 如果要求合并
                directionList = [2, 3, 0, 1]
                # 关于这个合并方向，我觉得对某一些方向的移动是有优先级的，感觉左右移动的价值大些，可以据此重新调整这个列表的排序
                nextDir = None
                hasmove = False  # 用来检验四个方向是不是可以合并，若四个方向都不可以，为False
                for direction in directionList:  # 对每一个方向都试一次
                    newBoard = board.copy()  # 备份棋盘
                    if newBoard.move(player, direction) == True:  # 向这个方向合并并且判断该合并是否有效
                        hasmove = True
                        if player == True:  # 先手情况下
                            tempVal = self._max(newBoard, not player, mode, n - 1, currentRound, a, b)
                        else:  # 后手情况下
                            tempVal = self._max(newBoard, not player, 'position', n - 1, currentRound + 1, a, b)
                        if tempVal < b:  # 选出局面价值最小的
                            b = tempVal
                        if b <= a:  # 如果b<=a,直接返回a，完成枝剪
                            return a
                if hasmove:  # 如果某个方向可以合并
                    return b  # 最后返回b，即最小值
                else:  # 如果四个方向都不可以合并
                    if player == True:  # 先手情况下
                        return self._max(board, not player, mode, n - 1, currentRound, a, b)
                    else:  # 后手情况下
                        return self._max(board, not player, 'position', n - 1, currentRound, a, b)

    def _max(self, board, player, mode, n, currentRound, a=-99999, b=99999):  # 当前玩家为自己
        if n == 0:
            return self.value(board)
        else:
            if mode == 'position':  # 要求下棋
                newBoard = board.copy()  # 备份棋盘
                another = board.getNext(player, currentRound)  # 可以在自己区域落子的范围
                available = board.getNone(not player)  # 可以在对手区域下棋的范围
                # 通过观察大部分棋局，发现绝大部分情况下在己方下棋收益更大，故己方有位置则直接在己方下
                if another != ():
                    newBoard.add(player, another)
                    if player == True:  # 先手情况下
                        return self._min(newBoard, not player, mode, n - 1, currentRound, a, b)
                    else:  # 后手情况下
                        return self._min(newBoard, not player, 'direction', n - 1, currentRound, )
                elif available:  # 在对方区域下棋时需要进行更进一步的决策
                    for choice in available:  # 依次考察在对方每个可落子点时的收益
                        newBoard = board.copy()  # 备份棋盘
                        newBoard.add(player, choice)  # 下在该点
                        if player == True:  # 先手情况下
                            tempVal = self._min(newBoard, not player, mode, n - 1, currentRound, a, b)
                        else:  # 后手情况下
                            tempVal = self._min(newBoard, not player, 'direction', n - 1, currentRound, a, b)
                        if tempVal > a:  # 选出局面价值最大的
                            a = tempVal
                        if b <= a:  # 如果b<=a,直接返回b，完成枝剪
                            return b
                    return a  # 最后返回a，即最大值
                else:  # 如果在棋盘上无可落子之地
                    if player == True:  # 先手情况下
                        return self._min(board, not player, mode, n - 1, currentRound, a, b)
                    else:  # 后手情况下
                        return self._min(board, not player, 'direction', n - 1, currentRound, a, b)

            else:  # 如果要求合并
                directionList = [0, 1, 2, 3]
                nextDir = None
                hasmove = False  # 用来检验四个方向是不是可以合并，若四个方向都不可以，为False
                for direction in directionList:  # 对每一个方向都试一次
                    newBoard = board.copy()  # 备份棋盘
                    if newBoard.move(player, direction) == True:  # 向这个方向合并并且判断该合并是否有效
                        hasmove = True
                        if player == True:  # 先手情况下
                            tempVal = self._min(newBoard, not player, mode, n - 1, currentRound, a, b)
                        else:  # 后手情况下
                            tempVal = self._min(newBoard, not player, 'position', n - 1, currentRound + 1, a, b)
                        if tempVal > a:  # 选出局面价值最大的
                            a = tempVal
                        if b <= a:  # 如果b<=a,直接返回b，完成枝剪
                            return b
                if hasmove:  # 如果某个方向可以合并
                    return a  # 最后返回a，即最大值
                else:  # 如果四个方向都不可以合并
                    if player == True:  # 先手情况下
                        return self._min(board, not player, mode, n - 1, currentRound, a, b)
                    else:  # 后手情况下
                        return self._min(board, not player, 'position', n - 1, currentRound, a, b)
